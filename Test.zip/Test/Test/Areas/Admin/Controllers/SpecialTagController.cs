﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Test.Data;
using Test.Models;

namespace Test.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class SpecialTagController : Controller
    {
        private readonly ApplicationDbContext _db;

        public SpecialTagController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.tags.ToList());
        }

        public IActionResult Create()
        {
            return View();
        }
        //create post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Create(SpecialTags special)
        {
            if(ModelState.IsValid)
            {
                _db.tags.Add(special);
                await _db.SaveChangesAsync();
                TempData["message"] = "Special Tag Added Successfully";
                return RedirectToAction(nameof(Index));
            }
            return View(special);
        }

        //edit get
        public async Task<IActionResult>Edit(int? id)
        {
            if(id==null)
            {
                return NotFound();
            }
            var sId = await _db.tags.FindAsync(id);
            if (sId == null)
            {
                return NotFound();
            }
            return View(sId);
        }

        //edit post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Edit(int id,SpecialTags specialTags)
        {
            if (id != specialTags.ID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _db.tags.Update(specialTags);
                await _db.SaveChangesAsync();
                TempData["message"] = "Special Tag Updated Successfully";
                return RedirectToAction(nameof(Index));
            }
            return View(specialTags);

        }

        //details get
        public async Task<IActionResult>Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var sID = await _db.tags.FindAsync(id);
            if(sID==null)
            {
                return NotFound();
            }
            return View(sID);
        }

        //Delete get
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var sID = await _db.tags.FindAsync(id);
            if (sID == null)
            {
                return NotFound();
            }
            return View(sID);
        }

        //Delete Post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Delete(int id,SpecialTags dtags)
        {
            if (id != dtags.ID)
            {
                return NotFound();
            }
            _db.tags.Remove(dtags);
            await _db.SaveChangesAsync();
            TempData["message"] = "Special Tag Deleted Successfully";
            return RedirectToAction(nameof(Index));
        }
    }
}