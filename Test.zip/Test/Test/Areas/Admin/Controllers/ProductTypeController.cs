﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Test.Data;
using Test.Models;

namespace Test.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductTypeController : Controller
    {
        private readonly ApplicationDbContext _db;

        public ProductTypeController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.productTypes.ToList());
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductTypes product)
        {
            if (ModelState.IsValid)
            {
                _db.productTypes.Add(product);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(product);


        }

        //edit get
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pID = await _db.productTypes.FindAsync(id);

            if(pID==null)
            {
                return NotFound();
            }

            return View(pID);
        }

        //edit post
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult>Edit(int id,ProductTypes product)
        {
            if(id!=product.Id)
            {
                return NotFound();
            }
            if(ModelState.IsValid)
            {
                _db.productTypes.Update(product);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        public async Task<IActionResult>Details(int? id)
        {
            if(id==null)
            {
                return NotFound();
            }
            var pID = await _db.productTypes.FindAsync(id);
            if(pID==null)
            {
                return NotFound();
            }

            return View(pID);
        }

        //delete get
        public async Task<IActionResult>Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var pid = await _db.productTypes.FindAsync(id);
            if (pid == null)
            {
                return NotFound();
            }
            return View(pid);
        }
        //delete post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Delete(int id,ProductTypes product)
        {
            if(id!=product.Id)
            {
                return NotFound();
            }
            _db.productTypes.Remove(product);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}